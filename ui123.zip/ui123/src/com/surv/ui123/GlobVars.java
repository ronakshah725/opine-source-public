package com.surv.ui123;


public class GlobVars {
	public static int screenwidth;
	public static boolean isDoing;
	public static int screenheight;
	public static int actionbarHt;
	public static int current_pts;
	public static int current_bal;
	public static int sort;
	public static boolean isExpanded = true;

//	public static int factor;
	public static String usrnm;

	public GlobVars() {

	}

	public static void gv_init() {
		
	}

}