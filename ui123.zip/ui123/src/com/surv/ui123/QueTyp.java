package com.surv.ui123;

class QueTyp {
	
	int _qno;	
	int _typ;
	

	public QueTyp() {

	}	
	
	public int getQno() {
		return this._qno;
	}
	
	public int getTyp() {
		return this._typ;
	}

	public void setQno(int _qno) {
		this._qno = _qno;
	}
	
	public void setTyp(int _typ) {
		this._typ = _typ;
	}

	
}