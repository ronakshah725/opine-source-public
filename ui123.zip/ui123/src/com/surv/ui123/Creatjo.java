package com.surv.ui123;

public class Creatjo 
{
	String addKey(String key)
	{
		return "\""+key+"\":";
	}
	String addValue(String val)
	{
		return "\""+val+"\"";
	}
}